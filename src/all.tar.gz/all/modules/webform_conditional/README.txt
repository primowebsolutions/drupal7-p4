
Webform Conditional

************************

This module adds the ability to hide/show components in the webform based on another fields value on the same page.
This modules allows showing and hiding of Webform components based on another components current value. It requires Webform 6.x-3.x.


If differs from the conditional fields currently in Webforms because it allows dynamically showing and hiding components on the same page. In core Webforms a field can only be conditional on field on a previous page.
On the component edit page the available current page select components are added to the "Component" listbox under "Conditional Rules" 
The current functions are:
Showing and hiding components based on a select field.
Fieldset can be hidden. 
Multiple values can be used to show component. For instance if a select has the values 1 to 10 then certain components could be shown when 1 to 5 are selected and other components could be shown if 6 to 10 are selected.
