Icon set freely provided by Social.me
http://jwloh.deviantart.com/art/Social-me-90694011