This directory contains files used by the Advanced Help module.
